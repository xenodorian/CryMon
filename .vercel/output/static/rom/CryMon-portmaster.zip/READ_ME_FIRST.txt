CryMon — copy into Ports, do not replace Ports
==============================================

On the SD card, open the EXISTING ports folder (EASYROMS/ports or roms/ports).

Copy ONLY these two things INTO it:

  CryMon.sh
  crymon     (the folder)

Do not replace the ports folder with this zip's contents.
Do not delete the PortMaster folder.
Do not copy any .xml files into ports.

If an older GEMWAR port is still there, delete GEMWAR.sh and the gemwar folder
so you are not running the stale build.

If Ports vanished from the R36S carousel:
  1. Plug the SD card into a computer.
  2. In the ports folder, delete gamelist.xml and gameinfo.xml if they are there.
  3. Leave the PortMaster folder alone.
  4. On the device, Start → UI Settings → Visible Systems → turn Ports on.
  5. Start → Advanced Settings → Parse Gamelists Only → Off.
  6. Start → Game Settings → Update Gamelists.
  7. Reboot.

The firmware is not bricked. Ports is hidden when its game list is empty.
