## Notes

GEMWAR is a 640×480 tamer walk. Same game as the in-browser cart and the Dreamcast disc.

**Do not unzip this archive over your ports folder.** That replaces the Ports game list.

Either:
- Drop this zip in PortMaster autoinstall and let PortMaster copy the two items, or
- Use gemwar-ports.zip instead: copy only `GEMWAR.sh` and the `gemwar` folder *into* the existing ports folder.

Never copy `gameinfo.xml` or `port.json` into ports. Never delete the PortMaster folder.

If Ports vanished from the carousel: delete `gamelist.xml` and `gameinfo.xml` from the ports folder, Start → UI Settings → Visible Systems → Ports on, Advanced Settings → Parse Gamelists Only off, Game Settings → Update Gamelists.

## Thanks

Homebrew original. IBM VGA 8×8 glyph sheet is public domain.
