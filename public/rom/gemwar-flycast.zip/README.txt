GEMWAR for Flycast
==================

640x480 VGA progressive, double-buffered, IBM 8x8 font, Maple pad
that does not spin on DMA (so buttons work in Flycast).
Copy gemwar-480p.cdi (or gemwar.cdi) into your Flycast games folder.
Delete any older gemwar.cdi first so Flycast cannot keep a stale copy.

Flycast settings that match this disc:
  General  Cable = VGA, Broadcast = NTSC
  Video    Internal Resolution = 640x480 (Native)
           Full Framebuffer Emulation ON
           Linear Interpolation OFF  (the check under Integer Scaling)
           Delay Frame Swapping OFF
           Texture Filtering = Force Nearest-Neighbor
           Frame Pacing OFF
  Advanced HLE BIOS ON  (this is homebrew; a retail BIOS is picky)

If the CDI is not listed, unzip this pack so these sit together:
  gemwar.gdi
  gemwar-track01.bin
  gemwar-track02.raw
  gemwar-track03.bin
Then in Flycast: Add Game Folder → that folder → open GEMWAR.

gemwar.cue + gemwar.bin is the same game as a MIL-CD. Keep both
in the same folder and open the .cue.
